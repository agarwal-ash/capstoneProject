﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;
using System.Threading.Tasks;
using FinalProject.Controllers;
using FinalProject.Models;

namespace FinalProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        [HttpGet]
        public List<Product> GetAll()
        {

            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT83476;Database=clothes;Integrated Security=false; User Id=sa;Password=guvi;");



                connection.Open();
                string query = "select * from products";



                SqlCommand cmd = new SqlCommand(query, connection);
                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {
                    List<Product> products = new List<Product>();
                    Product product = null;
                    while (a.Read())
                    {
                        product = new Product();
                        //product.id = (int)a["prod_id"];
                        product.name = a["prod_name"].ToString();
                        product.price =(int) a["prod_price"];
                        product.image = a["prod_image"].ToString();
                        product.desc = a["prod_desc"].ToString();
                        product.size = a["prod_size"].ToString();
                        product.category = a["prod_category"].ToString();
                        product.quantity =(int) a["prod_quantity"];



                        products.Add(product);
                    }
                    return products;
                }
            }
            catch (Exception)
            {

                throw;
            }

            return null;

        }



        //[HttpPost]
        //public string PostAll(string id, string name, string dept)
        //{
        //    string id1, name1, dept1;
        //    SqlConnection connection = new SqlConnection("Server=APINP-ELPT45775\\SQLEXPRESS;Database=c;Integrated Security=false; User Id=sa;Password=guvi;");
        //    connection.Open();
        //    string query = "insert into student(student_id,student_name,student_dept) values (@id1,@name1,@dept1)";
        //    SqlCommand cmd = new SqlCommand(query, connection);
        //    cmd.Parameters.Add("@id1", SqlDbType.NVarChar).Value = id;
        //    cmd.Parameters.Add("@name1", SqlDbType.NVarChar).Value = name;
        //    cmd.Parameters.Add("@dept1", SqlDbType.NVarChar).Value = dept;
        //    cmd.ExecuteReader();
        //    return null;



        //}

        
        

    }



}
