﻿using FinalProject.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data.SqlClient;
using System;
using System.Data;

namespace FinalProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : Controller
    {

        [HttpPost]
        public List<Admin> PostAll(Admin input)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT83476;Database=clothes;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();
                string query = "insert into dbo.products (prod_name,prod_price,prod_image,prod_desc,prod_size,prod_category,prod_quantity)" +
                    " values('" + input.name + @"','" + input.price + @"','" + input.image + @"','" + input.desc + @"','" + input.size + @"','" + input.category + @"','" + input.quantity + @"')";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {
                    List<Admin> addproducts = new List<Admin>();
                    Admin addproduct = null;
                    while (a.Read())
                    {
                        addproduct = new Admin();
                        addproduct.name = a["prod_name"].ToString();
                        addproduct.price = (int)a["prod_price"];
                        addproduct.image = a["prod_image"].ToString();
                        addproduct.desc = a["prod_desc"].ToString();
                        addproduct.size = a["prod_size"].ToString();
                        addproduct.category = a["prod_category"].ToString();
                        addproduct.quantity = (int)a["prod_quantity"];

                        addproducts.Add(addproduct);
                    }
                    return addproducts;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }



        [HttpGet()]
        public List<cart> getuser()
        {

            try
            {
                SqlConnection connection = new SqlConnection("server=apinp-elpt83476;database=clothes;integrated security=false; user id=sa;password=guvi;");

                connection.Open();

                string query = "select * from cart";

                SqlCommand cmd = new SqlCommand(query, connection);
 
                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {

                    List<cart> carts = new List<cart>();
                    cart cartt = null;
                    while (a.Read())
                    {

                        cartt = new cart();

                        cartt.email = a["user_email"].ToString();
                        cartt.name = a["prod_name"].ToString();
                        cartt.price = (int)a["prod_price"];
                        cartt.image = a["prod_image"].ToString();
                        cartt.desc = a["prod_desc"].ToString();
                        cartt.size = a["prod_size"].ToString();
                        cartt.category = a["prod_category"].ToString();
                        cartt.quantity = (int)a["prod_quantity"];

                        carts.Add(cartt);
                    }
                    return carts;

                }
            }
            catch (Exception)
            {

                throw;
            }

            return null;
        }


    }
}
