﻿using FinalProject.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data.SqlClient;
using System;
using System.Data;

namespace FinalProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : Controller
    {
        

        [HttpPost]
        public List<User> PostAll(User input)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT83476;Database=clothes;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();
                string query = "insert into dbo.users (user_name,user_email,user_phno,user_password,user_address) values('" + input.name + @"','" + input.email + @"','" + input.phno + @"','" + input.password + @"','" + input.address+ @"')";


                SqlCommand cmd = new SqlCommand(query, connection);
                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {
                    List<User> users = new List<User>();
                    User user = null;
                    while (a.Read())
                    {
                        user = new User();
                        user.id = Convert.ToInt32(a["id"]);
                        user.name = a["name"].ToString();
                        user.email= a["phone"].ToString();
                        user.phno = Convert.ToInt32(a["phno"]); ;
                        user.password = a["password"].ToString();
                        user.address = a["address"].ToString();


                        users.Add(user);
                    }
                    return users;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        //[HttpPost]

        //public string login(User user)
        //{
        //    SqlConnection connection = new SqlConnection("Server=APINP-ELPT83476;Database=clothes;Integrated Security=false;User Id=sa;Password=guvi;");

        //    SqlDataAdapter da = new("select * from users where user_email='" + input.email + "' and password='" + input.password + "'", connection);


        //    DataTable dt = new DataTable();
        //    da.Fill(dt);

        //    if(dt.Rows.Count > 0)
        //    {
        //        return "valid";
        //    }
        //    else
        //    {
        //        return "invalid";
        //    }


        //}


        [HttpGet]
        public List<User> GetAll()
        {

            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT83476;Database=clothes;Integrated Security=false; User Id=sa;Password=guvi;");



                connection.Open();
                string query = "select * from users";



                SqlCommand cmd = new SqlCommand(query, connection);
                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {
                    List<User> users = new List<User>();
                    User user = null;
                    while (a.Read())
                    {
                        user = new User();
                        //product.id = (int)a["prod_id"];
                        //product.name = a["prod_name"].ToString();
                        //product.price = (int)a["prod_price"];
                        //product.image = a["prod_image"].ToString();
                        //product.desc = a["prod_desc"].ToString();
                        //product.size = a["prod_size"].ToString();
                        //product.category = a["prod_category"].ToString();
                        //product.quantity = (int)a["prod_quantity"];
                        user.email = a["user_email"].ToString();
                        user.password = a["user_password"].ToString() ;
                        user.address = a["user_address"].ToString();
                        user.name = a["user_name"].ToString();
                        

                        users.Add(user);
                    }
                    return users;
                }
            }
            catch (Exception)
            {

                throw;
            }

            return null;

        }
    }
}
