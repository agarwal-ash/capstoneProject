﻿//using FinalProject.Models;
//using Microsoft.AspNetCore.Mvc;
//using System.Collections.Generic;
//using System.Data.SqlClient;
//using System;

//namespace FinalProject.Controllers
//{
//    public class PaymentController : Controller
//    {
//        [HttpPost]
//        public List<Admin> PostAll(Admin input)
//        {
//            try
//            {
//                SqlConnection connection = new SqlConnection("Server=APINP-ELPT83476;Database=clothes;Integrated Security=false;User Id=sa;Password=guvi;");

//                connection.Open();
//                string query = "insert into dbo.products (prod_name,prod_price,prod_image,prod_desc,prod_size,prod_category,prod_quantity)" +
//                    " values('" + input.name + @"','" + input.price + @"','" + input.image + @"','" + input.desc + @"','" + input.size + @"','" + input.category + @"','" + input.quantity + @"')";

//                SqlCommand cmd = new SqlCommand(query, connection);

//                var a = cmd.ExecuteReader();


                
//            }
//            catch (Exception)
//            {
//                throw;
//            }
//        }

//    }
//}


//sqlcommand cmd = new sqlcommand(query, connection);
//string query = "insert into Products(prod_name,prod_price,prod_image,prod_desc,prod_size,prod_category,prod_quantity)" 
//    + "values( @prod_name,@prod_price,@prod_image,@prod_desc,@prod_size,@prod_category,@prod_quantity);";



//cmd.Parameters.AddWithValue("@prod_name", input.name);
//cmd.Parameters.AddWithValue("@prod_price", input.price);
//cmd.Parameters.AddWithValue("@prod_image", input.desc);
//cmd.Parameters.AddWithValue("@prod_desc", input.image);
//cmd.Parameters.AddWithValue("@prod_size", input.size);
//cmd.Parameters.AddWithValue("@prod_category", input.category);
//cmd.Parameters.AddWithValue("@prod_quantity", input.quantity);



//if (cmd.ExecuteNonQuery() == 1)
//{
//    return input;
//}

//return null;
