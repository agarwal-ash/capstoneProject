﻿using FinalProject.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data.SqlClient;
using System;
using System.Data;

namespace FinalProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CartController : Controller
    {
        [HttpGet()]
        public List<cart> getuser(string uemail)
        {

            try
            {
                SqlConnection connection = new SqlConnection("server=apinp-elpt83476;database=clothes;integrated security=false; user id=sa;password=guvi;");

                connection.Open();
                string email = uemail;
                string query = "select * from cart where user_email=@email";

                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.Add("@email", SqlDbType.NVarChar).Value = uemail;

                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {

                    List<cart> carts = new List<cart>();
                    cart cartt = null;
                    while (a.Read())
                    {

                        cartt = new cart();

                        cartt.email = a["user_email"].ToString();
                        cartt.name = a["prod_name"].ToString();
                        cartt.price = (int)a["prod_price"];
                        cartt.image = a["prod_image"].ToString();
                        cartt.desc = a["prod_desc"].ToString();
                        cartt.size = a["prod_size"].ToString();
                        cartt.category = a["prod_category"].ToString();
                        cartt.quantity = (int)a["prod_quantity"];

                        carts.Add(cartt);
                    }
                    return carts;

                 }
                }
            catch (Exception)
            {

                throw;
            }

            return null;
        }


        //[HttpGet()]
        //public List<cart> getuser(string uname)
        //{

        //    try
        //    {
        //        SqlConnection connection = new SqlConnection("server=apinp-elpt83476;database=clothes;integrated security=false; user id=sa;password=guvi;");

        //        connection.Open();
        //        //string name = uname;
        //        string query = "select * from cart where user_name=@name";

        //        SqlCommand cmd = new SqlCommand(query, connection);
        //        cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = uname;
        //        var a = cmd.ExecuteReader();
        //        if (a.HasRows)
        //        {

        //            List<cart> carts = new List<cart>();
        //            cart cartt = null;
        //            while (a.Read())
        //            {

        //                cartt = new cart();

        //                cartt.email = a["user_email"].ToString();
        //                cartt.name = a["prod_name"].ToString();
        //                cartt.price = (int)a["prod_price"];
        //                cartt.image = a["prod_image"].ToString();
        //                cartt.desc = a["prod_desc"].ToString();
        //                cartt.size = a["prod_size"].ToString();
        //                cartt.category = a["prod_category"].ToString();
        //                cartt.quantity = (int)a["prod_quantity"];

        //                carts.Add(cartt);
        //            }
        //            return carts;

        //        }
        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }

        //    return null;
        //}






        [HttpPost]
        public List<cart> PostAll(cart input)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT83476;Database=clothes;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();
                string query = "insert into dbo.cart (user_email,prod_name,prod_price,prod_image,prod_desc,prod_size,prod_category,prod_quantity)" +
                    " values('" + input.email + @"','" + input.name + @"','" + input.price + @"','" + input.image + @"','" + input.desc + @"','" + input.size + @"','" + input.category + @"','" + input.quantity + @"')";


                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {
                    List<cart> addproducts = new List<cart>();
                    cart addproduct = null;
                    while (a.Read())
                    {
                        addproduct = new cart();
                        addproduct.email = a["user_email"].ToString();
                        addproduct.name = a["prod_name"].ToString();
                        addproduct.price = (int)a["prod_price"];
                        addproduct.image = a["prod_image"].ToString();
                        addproduct.desc = a["prod_desc"].ToString();
                        addproduct.size = a["prod_size"].ToString();
                        addproduct.category = a["prod_category"].ToString();
                        addproduct.quantity = (int)a["prod_quantity"];

                        addproducts.Add(addproduct);
                    }
                    return addproducts;

                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        //[HttpDelete]



        //public void DeleteAll(string img,string email)
        //{
        //    SqlConnection connection = new SqlConnection("Server=APINP-ELPT83476;Database=clothes;Integrated Security=false;User Id=sa;Password=guvi;");
        //    connection.Open();
        //    string img1=img,email1=email;
        //    string query = "delete from cart where prod_image=@img1 AND user_email=@email";
        //    SqlCommand cmd = new SqlCommand(query, connection);
        //    cmd.Parameters.Add("@img1", SqlDbType.NVarChar).Value = img;
        //    cmd.Parameters.Add("@email1", SqlDbType.NVarChar).Value = email;
        //    var a = cmd.ExecuteReader();
        //}




    }
}
