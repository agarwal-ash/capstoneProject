﻿namespace FinalProject.Models
{
    public class User
    {
        public int id { get; set; }
        public string name { get; set; }

        public string email { get; set; }

        public int phno { get; set; }

        public string password { get; set; }    

        public string address { get; set; }

    }
}
