﻿namespace FinalProject.Models
{
    public class Admin
    {
        public string name { get; set; }

        public int price { get; set; }

        public string image { get; set; }

        public string desc { get; set; }

        public string size { get; set; }

        public string category { get; set; }

        public int quantity { get; set; }
    }
}
