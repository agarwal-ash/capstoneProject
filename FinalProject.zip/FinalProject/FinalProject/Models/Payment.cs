﻿namespace FinalProject.Models
{
    public class Payment
    {

    }
}
