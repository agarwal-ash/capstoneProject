import { Component, OnInit } from '@angular/core';


import {MatDialog, MatDialogRef,MatDialogConfig} from '@angular/material/dialog';


@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  flag:any
  constructor(public dialog: MatDialog) {
    if(localStorage.getItem("login_status")=="null"||localStorage.getItem("login_status")!="loggedin")
    {
      this.flag=false;
    }
    else{
      this.flag=true;
    }
   }
  
  ngOnInit(): void {
    
  }

  changeStatus()
  {
    this.flag=false;
    localStorage.removeItem("login_status");
    // console.log(this.flag);
  }
 
}
