import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AddProductService } from '../services/add-product.service';
import { constant } from '../utilities/constant';
import { Admin } from '../utilities/admin';
import { AddToCartService } from '../services/add-to-cart.service';
import { ProductDetailsService } from '../services/product-details.service';
import { cart } from '../utilities/cart';
import { GetCartService } from '../services/get-cart.service';
import { GetFullCartService } from '../services/get-full-cart.service';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  name:string="";
  price:number=0;
  image:string="";
  desc:any="";
  size:string="";
  category:string="";
  quantity:number=0;
  
  admin:Admin={
    "name":"top",
    "price":0,
    "image":"xyz",
    "desc":"comfy",
    "size":"m",
    "category":"kids",
    "quantity":0
  }

  
  cartt:cart={
    "email":"aka@gmail.com",
    "name":"top",
    "price":0,
    "image":"xyz",
    "desc":"comfy",
    "size":"m",
    "category":"kids",
    "quantity":0
  }

  arr:cart[]=[];
  constructor(private ser:AddProductService,private router: Router,private httpclient: HttpClient,private cartobj: GetFullCartService ) { }

  ngOnInit(): void {
    this.cartobj.getAllCart().subscribe((response:any) => {
      console.log(response);
      this.arr=response;
  })
  }
  
  adding(name:string,price:number,image:string,desc:string,size:string,category:string,quantity:number)
  {
    console.log(name,price,image,desc,size,category,quantity);
    let temp:Admin={name:"",price:0,image:"",desc:"",size:"",category:"",quantity:0}

    temp.name=name;

    temp.price=price;

    temp.image=image;

    temp.desc=desc;

    temp.size=size;

    temp.category=category;

    temp.quantity=quantity;

    this.ser.postAllProducts(temp).subscribe((data:any)=>{

      console.log(data)

    })

  }
   
}

