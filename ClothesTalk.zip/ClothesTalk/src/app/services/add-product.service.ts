import { Injectable } from '@angular/core';
import { constant } from '../utilities/constant';
import { Admin } from '../utilities/admin';
import { HttpClient } from '@angular/common/http';
import { catchError, Observable, retry, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AddProductService {

  
  constructor(private httpclient: HttpClient) {}
  postAllProducts(add:Admin): Observable<any>
   {

    const headers = { 'content-type': 'application/json'}  

    const body=JSON.stringify(add);

    console.log(body)

    return this.httpclient.post(constant.postAllProducts.toString(),body,{'headers':headers});

  }

}
