import { Injectable } from '@angular/core';
import { constant } from '../utilities/constant';
import { cart } from '../utilities/cart';
import { HttpClient } from '@angular/common/http';
import { catchError, Observable, retry, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AddToCartService {

  constructor(private httpclient: HttpClient) { }
  postToCart(add:cart): Observable<any>
   {
    const headers = { 'content-type': 'application/json'}
    const body=add;
    return this.httpclient.post(constant.postToCart.toString(),add,{'headers':headers});

  }
}
