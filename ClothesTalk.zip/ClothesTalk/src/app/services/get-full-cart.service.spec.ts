import { TestBed } from '@angular/core/testing';

import { GetFullCartService } from './get-full-cart.service';

describe('GetFullCartService', () => {
  let service: GetFullCartService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetFullCartService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
