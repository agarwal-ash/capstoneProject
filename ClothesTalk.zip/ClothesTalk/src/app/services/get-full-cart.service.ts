import { Injectable } from '@angular/core';
import { cart } from '../utilities/cart';
import { HttpClient } from '@angular/common/http';
import { constant } from '../utilities/constant';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { SlicePipe } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class GetFullCartService {

  constructor(private httpclient : HttpClient) { }

  getAllCart(): Observable<cart[]> {
    return this.httpclient.get<cart[]>(constant.getAllCart.toString())     
  }

  handleError(er: any) {
    return throwError(() => {
      console.log(er);
    });
  }
}
