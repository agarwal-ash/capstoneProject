import { Injectable } from '@angular/core';
import { cart } from '../utilities/cart';
import { HttpClient } from '@angular/common/http';
import { constant } from '../utilities/constant';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { SlicePipe } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class GetCartService {

  constructor(private httpclient : HttpClient) { }

  getFromCart(email:string):Observable<any>{

    email=email.slice(1,email.length-1);
    return this.httpclient.get<any[]>("https://localhost:44368/api/Cart?uemail="+email);
  }

  handleError(er: any) {
      return throwError(() => {
        console.log(er);
      });
    }

   
}
