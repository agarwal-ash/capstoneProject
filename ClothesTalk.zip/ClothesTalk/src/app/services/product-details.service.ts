import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { products } from '../utilities/products';
import { constant } from '../utilities/constant';

@Injectable({
  providedIn: 'root',
})
export class ProductDetailsService {
  constructor(private httpclient: HttpClient) {}
  getAllProducts(): Observable<products[]> {
    return this.httpclient

      .get<products[]>(constant.getAllProducts.toString())

      .pipe(retry(1), catchError(this.handleError));
  }

  handleError(er: any) {
    return throwError(() => {
      console.log(er);
    });
  }
}
