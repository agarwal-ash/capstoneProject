import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { constant } from '../utilities/constant';
import { User } from '../utilities/user';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {

  constructor(private httpclient: HttpClient) {}
  addUser(user:User): Observable<any> {

    const headers = { 'content-type': 'application/json'}  

    const body=JSON.stringify(user);

    console.log(body)

    return this.httpclient.post(constant.postAllDetails.toString(),body,{'headers':headers});

  }

  getAllUsers(): Observable<User[]> {
    return this.httpclient

      .get<User[]>(constant.getAllUsers.toString())

      .pipe(retry(1), catchError(this.handleError));

      
  }

  handleError(er: any) {
    return throwError(() => {
      console.log(er);
    });
  }

}
