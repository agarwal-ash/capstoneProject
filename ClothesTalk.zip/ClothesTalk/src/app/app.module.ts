
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HomeComponent } from './home/home.component';
import { FooterComponent } from './footer/footer.component';
import { ReactiveFormsModule } from '@angular/forms';
import { PaymentComponent } from './payment/payment.component';
import {MatDialogModule} from '@angular/material/dialog';
import { LoginComponent } from './login/login.component';

import { AdminComponent } from './admin/admin.component';
import { ProductDisplayComponent } from './product-display/product-display.component';
import { NgModule, PACKAGE_ROOT_URL } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';

import { DisplayCartComponent } from './display-cart/display-cart.component';
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    FooterComponent,
    LoginComponent,
    AdminComponent,
    ProductDisplayComponent,
    PaymentComponent,
    DisplayCartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    MatDialogModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClientModule],
  bootstrap: [AppComponent]
})
export class AppModule { }
