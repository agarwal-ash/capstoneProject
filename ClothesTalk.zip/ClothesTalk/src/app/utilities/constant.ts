export module constant{
    let data:any=localStorage.getItem("login_user");
    data=data.replace("@","%40");
    export const getAllProducts="https://localhost:44368/api/WeatherForecast";
    export const postAllDetails="https://localhost:44368/api/User";
    export const getAllUsers="https://localhost:44368/api/User";
    export const postAllProducts="https://localhost:44368/api/Admin";
    export const postToCart="https://localhost:44368/api/Cart"
    export const getFromCart="https://localhost:44368/api/Cart?uemail=data";
    export const getAllCart="https://localhost:44368/api/Admin";
}