export interface products{
    id:number;
    name:string;
    price:number;
    image:string;
    desc:string;
    size:string;
    category:string;
    quantity:number;
}