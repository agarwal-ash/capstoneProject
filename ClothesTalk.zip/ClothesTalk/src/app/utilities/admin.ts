export interface Admin{
    name:string;
    price:number;
    image:string;
    desc:string;
    size:string;
    category:string;
    quantity:number;
}