export interface User{
    // id:number;
    name:string;
    email:string;
    phno:string;
    password:string;
    address:string;
}