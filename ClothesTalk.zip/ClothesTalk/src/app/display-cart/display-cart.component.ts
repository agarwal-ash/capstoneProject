import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AddToCartService } from '../services/add-to-cart.service';
import { ProductDetailsService } from '../services/product-details.service';
import { cart } from '../utilities/cart';
import { GetCartService } from '../services/get-cart.service';

@Component({
  selector: 'app-display-cart',
  templateUrl: './display-cart.component.html',
  styleUrls: ['./display-cart.component.css']
})




export class DisplayCartComponent implements OnInit {

  cartt:cart={
    "email":"aka@gmail.com",
    "name":"top",
    "price":0,
    "image":"xyz",
    "desc":"comfy",
    "size":"m",
    "category":"kids",
    "quantity":0
  }
  sum:number=0;
  i:any;
  arr:cart[]=[];
  constructor(private router:Router, private cartobj: GetCartService,private productobj: ProductDetailsService) { }

  ngOnInit(): void {
    // let data=localStorage.getItem("login_user")|| "";
    let data:any=localStorage.getItem("login_user");
    console.log(data);
    data=data.replace("@","%40");
    console.log(data);
    this.cartobj.getFromCart(data).subscribe((response:any) => {
      console.log(response,'home')
      console.log(response);
      this.arr=response;
      for(let i=0;i<response.length;i++){
        this.sum=this.sum+response[i].price
      }
      console.log(this.sum);
  })

}

}
