import { Component, OnInit } from '@angular/core';
import { cart } from '../utilities/cart';
import { state } from '@angular/animations';
import { Router } from '@angular/router';
import { products} from '../utilities/products';
import { ProductDetailsService } from '../services/product-details.service';
import { AddToCartService } from '../services/add-to-cart.service';

@Component({
  selector: 'app-product-display',
  templateUrl: './product-display.component.html',
  styleUrls: ['./product-display.component.css']
})

export class ProductDisplayComponent implements OnInit {

  arr:products[]=[];

  init:boolean=true;


  cartt:cart={
    "email":"aka@gmail.com",
    "name":"top",
    "price":0,
    "image":"xyz",
    "desc":"comfy",
    "size":"m",
    "category":"kids",
    "quantity":0
  }

  constructor(private router:Router, private productobj: ProductDetailsService, private cartobj: AddToCartService) { }

  ngOnInit(): void {

    this. productobj.getAllProducts().subscribe((response:any) => {
      // console.log(response);
      this.arr = response;
      if(this.arr.length >0){
        this.init = false;
      }

    })

  }

  cart(image:string,name:string,desc:string,size:string,price:number,category:string)
  {
    console.log("cl");
    console.log(image,name,desc,size,price);
    
    let temp:cart={email:"",name:"",price:0,image:"",desc:"",size:"",category:"",quantity:0}

    let data = localStorage.getItem("login_user");
    console.log(data);
    temp.email= String(data?.slice(1, data.length-1)) || "";

    temp.name=name;

    temp.price=price;

    temp.image=image;

    temp.desc=desc;

    temp.size=size;

    temp.category=category;

    temp.quantity=1;

    console.log(temp)

    this.cartobj.postToCart(temp).subscribe((data:any)=>{
      console.log(data)
    })
  }
}





