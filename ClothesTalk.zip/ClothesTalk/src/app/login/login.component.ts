import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserDetailsService } from '../services/user-details.service';
import { User } from '../utilities/user';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  constructor(private ser: UserDetailsService, private router: Router) {}

  id: number = 0;
  name: string = '';
  email: string = '';
  phoneno: string = '';
  password: string = '';
  address: string = '';

  uname: string = '';
  upass: string = '';

  arr: User[] = [];

  init: boolean = true;

  i: any;
  flag: boolean = false;

  ngOnInit(): void {
    this.ser.getAllUsers().subscribe((response: any) => {
      // console.log(response,'home')

      this.arr = response;
      // console.log(response);
      if (this.arr.length > 0) {
        this.init = false;
      }
    });
  }

  submit(
    name: string,
    email: string,
    password: string,
    phoneno: string,
    address: string
  ) {
    console.log(name);

    console.log(phoneno);

    console.log(email);

    console.log(password);

    let temp: User = {
      name: '',
      phno: '',
      email: '',
      password: '',
      address: '',
    };

    temp.name = name;

    temp.phno = phoneno;

    temp.email = email;

    temp.password = password;

    temp.address = address;

    this.ser.addUser(temp).subscribe((data: any) => {
      console.log(data);
    });
  }

  logIn(uname: string, upass: string) {
    localStorage.setItem("login_user",JSON.stringify(uname));
    localStorage.setItem("login_status","loggedin");
    // console.log(uname);
    if(uname == "admin1@gmail.com" )

      {
        this.router.navigate(['/admin']);
      }
    else{
      for (this.i = 0; this.i < this.arr.length; this.i++) {
        if (
          uname == this.arr[this.i].email &&
          upass == this.arr[this.i].password
        ) {
          this.flag = true;  
          break;
        }
      }
  
      console.log(this.flag);
  
      if (this.flag == true) {
        this.router.navigate(['/', 'product-display']);
      } else {
        // Swal.fire({
        //   icon: 'error',
  
        //   title: 'Oops...',
  
        //   text: 'Enter a valid E-mail or password',
        // });
        alert("invalid!");
      }
    }  
    
  }
}
